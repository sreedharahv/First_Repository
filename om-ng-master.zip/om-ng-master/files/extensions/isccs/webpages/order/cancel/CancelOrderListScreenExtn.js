
scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/order/cancel/CancelOrderListScreenExtnUI", "scbase/loader!isccs/utils/BaseTemplateUtils", "scbase/loader!isccs/utils/OrderLineUtils", "scbase/loader!isccs/utils/OrderUtils", "scbase/loader!isccs/utils/UIUtils", "scbase/loader!isccs/utils/WidgetUtils", "scbase/loader!sc/plat/dojo/utils/BaseUtils", "scbase/loader!sc/plat/dojo/utils/ControllerUtils", "scbase/loader!sc/plat/dojo/utils/EventUtils", "scbase/loader!sc/plat/dojo/utils/GridxUtils", "scbase/loader!sc/plat/dojo/utils/ModelUtils", "scbase/loader!sc/plat/dojo/utils/PaginationUtils", "scbase/loader!sc/plat/dojo/utils/ScreenUtils", "scbase/loader!sc/plat/dojo/utils/WidgetUtils","scbase/loader!sc/plat/dojo/utils/WizardUtils","scbase/loader!sc/plat/dojo/utils/EditorUtils"]
,
function(			 
			    _dojodeclare, _extnCancelOrderListScreenExtnUI, _isccsBaseTemplateUtils, _isccsOrderLineUtils, _isccsOrderUtils, _isccsUIUtils, _isccsWidgetUtils, _scBaseUtils, _scControllerUtils, _scEventUtils, _scGridxUtils, _scModelUtils, _scPaginationUtils, _scScreenUtils, _scWidgetUtils, _scWizardUtils, _scEditorUtils
){ 
	return _dojodeclare("extn.order.cancel.CancelOrderListScreenExtn", [_extnCancelOrderListScreenExtnUI],{
	
	checkLineModificationAllowed: function(
        orderLinesList) {
            var isLinesModificationAllowed = false;
            var rowsCount = 0;
            rowsCount = _scBaseUtils.getAttributeCount(
            orderLinesList);
            if (
            _scBaseUtils.equals(
            rowsCount, 0)) {
                isLinesModificationAllowed = true;
            }
            for (
            var i = 0;
            i < rowsCount;
            i = i + 1) {
                var indexObj = null;
                indexObj = orderLinesList[
                i];
                var availableCancelQty = 0;
                availableCancelQty = _isccsOrderUtils.calculateOrder_CancelQuantityWOFormat(
                this.txQtyRuleSetValue, indexObj, false);
                
                var maxLineStatus = indexObj.MaxLineStatus;
                if (
                availableCancelQty > 0 &&  maxLineStatus.indexOf("9000")<0) {
                    isLinesModificationAllowed = true;
                    break;
                }
            }
            var eventDefn = null;
            var blankModel = null;
            eventDefn = {};
            blankModel = {};
            eventDefn["argumentList"] = blankModel;
            _scBaseUtils.setAttributeValue("argumentList.isLinesModificationAllowed", isLinesModificationAllowed, eventDefn);
            _scEventUtils.fireEventToParent(
            this, "initializeLayout", eventDefn);
        },
		
		 isGridRowDisabled: function(
		 rowData, screen) {
            var availableCancelQty = 0;
            var maxLineStatus = rowData.MaxLineStatus;
            availableCancelQty = _isccsOrderUtils.calculateOrder_CancelQuantityWOFormat(
            this.txQtyRuleSetValue, rowData, false);
            if (
            availableCancelQty <= 0 || maxLineStatus.indexOf("9000")>=0) {
                return true;
            } else {
                return false;
            }
        }
	
});
});
