# Omincron OMS

This is the git repository for Omnicron OMS extensions

## To get setup

First ensure that you have java jdk 8 setup especially if you are using a mac: https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html

(Linux users - the dev toolkit for sterling comes with ibm jdk 8 with linux binaries)

You should have setup docker. If you are using a mac, then see the notes below for mac for docker desktop for mac edge version.

The recommended approach is that you fork the omnicron/om-ng repo so that you can push your changes to your fork and then raise a pull request on the upstream  to merge your changes. You can always merge upstream to your fork to keep it in sync

as per https://help.github.com/en/github/collaborating-with-issues-and-pull-requests/working-with-forks

The build.properties assumes that 

- Your fork of omnicron/om-ng git repo is cloned into ~/git/omnicron/om-ng
- Your fork of omnicron/isf git repo is cloned into ~/git/omnicron/isf
- Your sterling devtoolkit is installed in ~/devtoolkit_docker
  
  The latest sterling devtoolkit is 20.1.2.b1_20200225-1220 and is available here : https://ibm.box.com/v/om-devtoolkit

  You should also install the certificate to access the Omnicron OM SaaS dev instance: 
  https://ibm.box.com/v/omnicron-certificate 

  - If you already have an existing Sterling devtoolkit setup then perform Step 1 and 2 from https://www.ibm.com/support/knowledgecenter/SSGTJF/developing/customization/t_omc_setupdockerdevtktenv.html  (you can run setup in step 3, but that will be wasted if you do it just now, so hold off that for a minute)
  
- You have a working maven install with mvn available on your path

set these environment variables  in your shell profile usually ~/.bash_profile

```shell
export MAVEN_OPTS="-Xmx1024m"
export JAVA_HOME=<Your JAVA HOME for jdk 1.8 - please use version 241 >
export PATH=$JAVA_HOME/bin:$PATH
```

OPTIONAL: if you are looking to change the build.properties values then create a build folder and copy the build.properties in this folder This is where you will run build commands from. It will create a log file called build.log inside logs in this folder. Keep in mind that running build.sh will always checkout the latest version of code from git and replace any local changes. So always commit and push your changes before running build.sh

```shell
mkdir ~/build
ln -s ~/build/build.sh ~/git/omnicron/om-ng/build/build/.sh
cp ~/build/build.properties ~/git/omnicron/om-ng/build/build.properties
```


## This Section only For mac users - not required for linux
This has been tested on docker desktop edge
https://docs.docker.com/docker-for-mac/edge-release-notes/

We have deliberately chosen to use docker-sync when running this on mac to minimse cpu utilisation.

https://docker-sync.readthedocs.io/en/latest/getting-started/installation.html

You also need to install coreutils for om-compose.sh to work correctly on Mac OS catalina. Suggest you use homebrew (installation here: https://brew.sh/)

You also need maven setup and available on your path

```shell
brew install coreutils maven
```

set these environment variables  in your shell profile usually ~/.bash_profile

```shell
export HOST_OS=mac
export MAVEN_OPTS=\"-Xmx1024m\"
export JAVA_HOME="$(/usr/libexec/java_home -v 1.8)"
export PATH=$JAVA_HOME/bin:$PATH
```


## Common steps

Once ready run from the build folder
(either ~/git/omnicron/om-ng/build or your custom build folder)

```shell
./build.sh setup
```
This does the following internally (NO need to run these, just described here, incase you need to ever run some of these manually)

- Create a lib folder inside the main folder and setup dependencies using maven

```shell
cd ~/git/omnicron/om-ng
mkdir -p lib src-maven
mvn dependency:copy-dependencies
```

- symlink devtoolkit runtime to /opt/SSFS_9.5/runtime as required by the sterling build process. This requires your root process

```shell
sudo mkdir -p /opt/SSFS_9.5
sudo ln -s ~/devtoolkit_docker/runtime /opt/SSFS_9.5/runtime
```

- MAC ONLY: and then run the following to create the folders for the various docker volumes that sterling needs

```shell
mkdir -p ~/docker_sync_vol/om_saas/db2insthome ~/docker_sync_vol/om_saas/db_jars     ~/docker_sync_vol/om_saas/ear         ~/docker_sync_vol/om_saas/logs/wls_logs  ~/docker_sync_vol/om_saas/logs/app_logs ~/docker_sync_vol/om_saas/logs/agent_logs       ~/docker_sync_vol/om_saas/shared      ~/docker_sync_vol/om_saas/var_mqm
```

- MAC ONLY: The following appears to be required by OMS to install java jars
```shell
mkdir -p ~/Library/Java/Extensions
```

- the run the following to setup the linux OR mac/docker-sync version of devtoolkit files from git

```shell
cd build
./build.sh copy-devtoolkit-files
```
- MAC ONLY: then finally starts docker sync
```
cd ~/devtoolkit_docker/compose/docker
docker-sync start
```

This will start docker sync which will setup containers for all the volumes.



## Note regarding use of docker sync
You must always run docker-sync start before running ./om-compose.sh start or setup when using this on mac

Remember if you decide to reset your sterling install i.e.
```
cd ~/devtoolkit-docker/compose
./om-compose.sh wipe-clean
```

then you also need to do
```
cd ~/devtoolkit_docker/compose/docker
docker-sync clean
docker-sync stop
```

to clean up the volumes inside the docker sync folders

## Common steps

once you are ready with your linux or mac setup you can now do step 3 from https://www.ibm.com/support/knowledgecenter/SSGTJF/developing/customization/t_omc_setupdockerdevtktenv.html
```
cd ~/devtoolkit_docker/compose
./om-compose.sh setup
```

To setup a fresh instance of om using docker-sync

and then
```
cd ~/build
./build.sh extensions
```

To build and deploy into your local oms.

## Using the App Manager

App manager is installed in $HOME/devtoolkit_docker/runtime/ApplicationManagerClient/

To start the app manager and connect to your localhost you can use the following syntax

```
java -Xms256m -Xmx256m -jar $HOME/devtoolkit_docker/runtime/ApplicationManagerClient/client_9.5.jar -URL https://localhost:9443 -U admin -CR /smcfs -P password
```

If you want to connect to oms-dev1 then simply change the -URL, -U and -P params for the url, your userid and password respectively
For the actual SaaS environment, you need to use IE to open app manager unfortunately as the standalone app manager jar will not connect.

To start SMC or channel application manager pass ` -mode SMC` or `-mode YCD` at the end respectively

For those who didn't install sterling, you can get it from here: https://ibm.box.com/v/oms-app-manager

Take the `20.1.2.b1_20200225-1220` version as that is what we are currently using







